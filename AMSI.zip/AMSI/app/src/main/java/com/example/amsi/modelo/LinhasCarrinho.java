package com.example.amsi.modelo;

public class LinhasCarrinho {
}
