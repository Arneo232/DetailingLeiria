package com.example.amsi.listeners;

public interface RegisterListener {
    void onSignup(String message);
}
