package com.example.amsi.listeners;

import com.example.amsi.modelo.Utilizador;

public interface UtilizadorListener {

    void onRefreshUtilizador(Utilizador utilizador);

}