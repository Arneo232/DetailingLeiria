package com.example.amsi.listeners;

import com.example.amsi.modelo.Produto;

public interface ProdutoListener {

    void onRefreshDetalhes(Produto produto);
}
